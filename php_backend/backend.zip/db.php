<?php
// PHP Database Connection Configuration
// Automatically selects the correct DB based on environment.

$is_local = ( $_SERVER['REMOTE_ADDR'] === '127.0.0.1' || $_SERVER['REMOTE_ADDR'] === '::1' );

$host = $is_local ? 'localhost' : 'localhost';
$user = $is_local ? 'root'      : 'caldim_admin';
$pass = $is_local ? 'Caldim@2026' : 'Caldim@2026';
$db   = $is_local ? 'caldimwebsite' : 'caldim_web_db';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Database Connection Failed: " . $conn->connect_error]));
}

// Ensure the enquiries table exists
$sql = "CREATE TABLE IF NOT EXISTS enquiries (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    first_name    VARCHAR(255)  NOT NULL,
    last_name     VARCHAR(255)  NOT NULL,
    email         VARCHAR(255)  NOT NULL,
    contact_number VARCHAR(50)  NOT NULL,
    project_info  TEXT          NOT NULL,
    submitted_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
$conn->query($sql);

// Table for OTPs (temporary storage)
$sql_otp = "CREATE TABLE IF NOT EXISTS otp_verification (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    email       VARCHAR(255) NOT NULL,
    otp         VARCHAR(10)  NOT NULL,
    expires_at  DATETIME     NOT NULL,
    created_at  DATETIME     DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
$conn->query($sql_otp);

return $conn;
?>
