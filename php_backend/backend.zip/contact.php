<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER["REQUEST_METHOD"] == "OPTIONS") {
    http_response_code(200);
    exit;
}

require_once 'db.php';

// Get JSON input
$input = file_get_contents("php://input");
$data = json_decode($input, true);

$firstName = $data['firstName'] ?? '';
$lastName = $data['lastName'] ?? '';
$email = $data['email'] ?? '';
$contactNumber = $data['contactNumber'] ?? '';
$projectInfo = $data['projectInfo'] ?? '';

if (empty($firstName) || empty($lastName) || empty($email) || empty($contactNumber) || empty($projectInfo)) {
    echo json_encode(["success" => false, "message" => "All fields are required."]);
    exit;
}

// 1. Save to Database
$stmt = $conn->prepare("INSERT INTO enquiries (first_name, last_name, email, contact_number, project_info) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $firstName, $lastName, $email, $contactNumber, $projectInfo);
$stmt->execute();

// 2. Send Emails (Notification to CALDIM)
$to = "support@caldimengg.in";
$subject = "New Project Enquiry from $firstName $lastName";
$name = "$firstName $lastName";

$headers = "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
$headers .= "From: CALDIM Website <$to>\r\n";
$headers .= "Reply-To: $email\r\n";

$message_admin = "
    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f9f9f9; padding: 40px;'>
        <h2 style='color: #1d4ed8;'>New Project Enquiry</h2>
        <p><strong>Name:</strong> $name</p>
        <p><strong>Email:</strong> $email</p>
        <p><strong>Contact:</strong> $contactNumber</p>
        <p><strong>Project Info:</strong><br/> $projectInfo</p>
    </div>
";

// 3. Auto-reply to Client
$message_client = "
    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f9f9f9; padding: 40px;'>
        <h2 style='color: #1d4ed8;'>Thank You, $firstName!</h2>
        <p>We have received your enquiry and our team will get back to you within 24–48 hours.</p>
    </div>
";

// Use mail() function - note that for SMTP (Zoho) you might need PHPMailer
// This uses the default PHP mail() which BigRock supports.
mail($to, $subject, $message_admin, $headers);
mail($email, "We received your enquiry — CALDIM Engineering", $message_client, $headers);

echo json_encode(["success" => true, "message" => "Email sent successfully."]);
?>